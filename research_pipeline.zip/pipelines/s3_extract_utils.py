"""
s3_extract_utils.py
===================
Extraction of the raw .tar.gz archives (MSResource, MSRTQps, MSCallGraph)
from S3 into local disk, so Spark can then read the plain CSVs.

Why local disk and not DBFS/S3 directly: extraction is a CPU-bound
operation done via Python's tarfile module, and writing many small
extracted files straight to S3/DBFS is much slower and racks up more S3
requests than extracting locally first and then having Spark do one bulk
`.csv()` read off local disk. LOCAL_EXTRACT_ROOT (config.py, default /tmp)
is scratch space, not a data store, and is safe to clear after each run.

HOW THE S3 -> LOCAL COPY WORKS (and why it changed twice):
  1. dbutils.fs.cp seemed natural but is restricted to /Workspace-only
     local destinations on some Unity-Catalog-governed clusters (including
     Serverless), raising LocalFilesystemAccessDeniedException for /tmp.
  2. Reading via Spark's binaryFile source + .collect() avoided that, but
     this cluster runs Spark Connect, which has its own gRPC message-size
     limit for data returned to the Python client. These per-table tar.gz
     archives run into the hundreds of MB, well past that limit, so
     .collect() on the file's bytes fails (surfaced as a vague
     FAILED_READ_FILE.NO_HINT rather than a clear size-limit error).
  3. This version instead requests short-lived, path-scoped AWS
     credentials directly from Unity Catalog (the same mechanism UC uses
     internally to vend credentials to Spark, exposed here for direct use)
     and downloads via boto3, which streams straight from S3 to local disk
     in chunks — no Spark Connect involved at all, so no message-size
     limit applies regardless of file size.

Requires: a Unity Catalog external location (+ storage credential) granting
this bucket/prefix READ FILES access to the running user/service principal,
on a Unity-Catalog-enabled cluster — see the README's "S3 authentication"
section. Also requires the `databricks-sdk` and `boto3` packages, both
preinstalled on standard Databricks Runtime / Serverless environments.
"""

import os
import glob
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urlparse

from config import RAW_ROOT, LOCAL_EXTRACT_ROOT


def _list_s3_tarballs(table: str, dbutils) -> list[str]:
    """List .tar.gz files for a table under RAW_ROOT via dbutils.fs (works
    with s3:// paths on Databricks, credentials vended by the UC external
    location, without extra deps)."""
    remote_dir = f"{RAW_ROOT}/{table}"
    entries = dbutils.fs.ls(remote_dir)
    return sorted(e.path for e in entries if e.path.endswith(".tar.gz"))


def _get_temp_s3_client(scope_url: str):
    """
    Request short-lived AWS credentials from Unity Catalog, scoped to
    `scope_url` (an external-location-governed S3 path), and return a
    boto3 S3 client built from them.

    This is the same credential-vending mechanism Spark uses internally
    for s3:// reads under a UC external location, exposed here directly so
    we can stream large files with boto3 instead of routing bytes through
    Spark Connect (which has a message-size limit unsuitable for large
    files — see the module docstring).
    """
    import boto3
    try:
        from databricks.sdk import WorkspaceClient
        from databricks.sdk.service.catalog import PathOperation
    except ImportError as e:
        raise ImportError(
            "databricks-sdk is required for temporary credential vending. "
            "It's preinstalled on standard Databricks Runtime/Serverless — "
            "if this import fails, run `%pip install databricks-sdk` in a "
            "cell and restart Python."
        ) from e

    try:
        w = WorkspaceClient()
        creds = w.temporary_path_credentials.generate_temporary_path_credentials(
            url=scope_url, operation=PathOperation.PATH_READ,
        ).aws_temp_credentials
    except AttributeError as e:
        raise AttributeError(
            "The databricks-sdk API for temporary path credentials didn't "
            "match what this code expects (SDK versions have changed this "
            "surface). Run `import databricks.sdk; print(databricks.sdk.__version__)` "
            "and `help(WorkspaceClient().temporary_path_credentials)` in a "
            "cell and share the output so this can be updated to match your "
            "SDK version."
        ) from e

    return boto3.client(
        "s3",
        aws_access_key_id=creds.access_key_id,
        aws_secret_access_key=creds.secret_access_key,
        aws_session_token=creds.session_token,
    )


def _parse_s3_path(s3_path: str):
    """s3://bucket/key/path.tar.gz -> ('bucket', 'key/path.tar.gz')"""
    parsed = urlparse(s3_path)
    return parsed.netloc, parsed.path.lstrip("/")


# def _copy_one(remote_path: str, local_dir: str, s3_client) -> str:
#     """
#     Stream-download a single tar.gz from S3 to local disk via boto3.
#     Handles files of any size — boto3's download_file streams in chunks
#     rather than materializing the whole object in memory, and never
#     touches Spark Connect, so no gRPC message-size limit applies.
#     """
#     filename = os.path.basename(remote_path)
#     local_path = os.path.join(local_dir, filename)
#     if os.path.exists(local_path) and os.path.getsize(local_path) > 0:
#         return f"  skip copy  {filename} (already local)"

#     bucket, key = _parse_s3_path(remote_path)
#     s3_client.download_file(bucket, key, local_path)

#     size_mb = os.path.getsize(local_path) / 1e6
#     return f"  copied     {filename} ({size_mb:.0f} MB)"

# s3_extract_utils.py — replace the boto3 path with dbutils.fs.cp
def _copy_one(remote_path: str, local_dir: str, dbutils) -> str:
    filename = os.path.basename(remote_path)
    local_path = os.path.join(local_dir, filename)
    if os.path.exists(local_path) and os.path.getsize(local_path) > 0:
        return f"  skip copy  {filename} (already local)"

    dbutils.fs.cp(remote_path, f"file:{local_path}")  # mediated by UC external location, not temp creds
    size_mb = os.path.getsize(local_path) / 1e6
    return f"  copied     {filename} ({size_mb:.0f} MB)"


def _extract_one(local_tarball: str, out_dir: str) -> str:
    """
    Extract a single local tar.gz using Python's built-in tarfile module.

    Deliberately does NOT shell out to the system `tar` binary via
    subprocess — Serverless compute runs notebooks in a sandboxed
    environment that may not expose a shell/binary the same way a classic
    cluster does, and tarfile has no such dependency.
    """
    csv_name = os.path.basename(local_tarball).replace(".tar.gz", ".csv")
    out_file = os.path.join(out_dir, csv_name)

    if os.path.exists(out_file) and os.path.getsize(out_file) > 0:
        return f"  skip extract  {csv_name} (already extracted)"

    import tarfile
    with tarfile.open(local_tarball, mode="r:gz") as tf:
        try:
            tf.extractall(path=out_dir, filter="data")  # PEP 706 safe-extraction filter (Python 3.12+, backported to patched 3.8-3.11)
        except TypeError:
            # Older Python without the `filter` kwarg on extractall at all.
            tf.extractall(path=out_dir)

    if not os.path.exists(out_file):
        raise RuntimeError(
            f"Extraction of {local_tarball} completed but expected output "
            f"{out_file} was not found — check the archive's internal file naming."
        )

    size_mb = os.path.getsize(out_file) / 1e6
    return f"  extracted     {csv_name} ({size_mb:.0f} MB)"


def extract_table_from_s3(table: str, dbutils, max_workers: int = 4) -> str:
    """
    Copy every .tar.gz for `table` from S3 to local disk, extract in
    parallel, and return the local directory containing the extracted CSVs.

    Parameters
    ----------
    table : str
        One of "MSResource", "MSRTQps", "MSCallGraph" (matches the S3
        sub-folder name under config.RAW_ROOT).
    dbutils : the Databricks `dbutils` global (pass it in explicitly so this
        module stays importable/testable outside a notebook). Used for
        listing files in S3 (dbutils.fs.ls). The actual file download uses
        boto3 with UC-vended temporary credentials, not dbutils.fs, so it
        isn't affected by the /Workspace-only local-path restriction or
        Spark Connect's message-size limit.
    max_workers : int
        Parallelism for both the S3 copy and the tar extraction steps.

    Returns
    -------
    str : local directory path holding the extracted CSV(s) for this table.
    """
    local_tar_dir = os.path.join(LOCAL_EXTRACT_ROOT, "tarballs", table)
    local_csv_dir = os.path.join(LOCAL_EXTRACT_ROOT, "csv", table)
    os.makedirs(local_tar_dir, exist_ok=True)
    os.makedirs(local_csv_dir, exist_ok=True)

    tarballs = _list_s3_tarballs(table, dbutils)
    if not tarballs:
        raise FileNotFoundError(f"No .tar.gz found under {RAW_ROOT}/{table}/")

    # One set of temp credentials scoped to this table's whole prefix,
    # reused across all files/threads rather than re-requesting per file.
    table_prefix = f"{RAW_ROOT}/{table}"
    s3_client = _get_temp_s3_client(table_prefix)

    print(f"\n{table}: copying {len(tarballs)} archive(s) from S3 (streaming via boto3) ...")
    t0 = time.time()
    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = {pool.submit(_copy_one, tb, local_tar_dir, s3_client): tb for tb in tarballs}
        for f in as_completed(futures):
            print(f.result())
    print(f"  done in {(time.time() - t0) / 60:.1f} min")

    local_tarballs = sorted(glob.glob(os.path.join(local_tar_dir, "*.tar.gz")))
    print(f"\n{table}: extracting {len(local_tarballs)} archive(s) ...")
    t0 = time.time()
    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = {pool.submit(_extract_one, tb, local_csv_dir): tb for tb in local_tarballs}
        for f in as_completed(futures):
            print(f.result())

    csv_files = glob.glob(os.path.join(local_csv_dir, "*.csv"))
    size_gb = sum(os.path.getsize(f) for f in csv_files) / 1e9
    print(f"  \u2713 {table}: {len(csv_files)} CSV(s) ready, {size_gb:.1f} GB "
          f"({(time.time() - t0) / 60:.1f} min)")

    return local_csv_dir


def cleanup_local_extract():
    """Remove all local scratch extraction data. Safe to call after each
    table has been read into Spark and its Parquet output written."""
    import shutil
    shutil.rmtree(LOCAL_EXTRACT_ROOT, ignore_errors=True)
    print(f"Cleaned local scratch dir: {LOCAL_EXTRACT_ROOT}")
