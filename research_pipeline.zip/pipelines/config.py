"""
config.py
=========
Single source of truth for paths, schemas, and constants used by both the
ETL stage (etl.py) and the feature-engineering stage (feature_engineering.py).

Import this module from Databricks notebooks:

    from config import *

Override any S3 path or constant via Databricks widgets in the calling
notebook (see notebooks/01_etl_pipeline.py for the pattern) rather than
editing this file per-environment.
"""

from pyspark.sql.types import (
    StructType, StructField, LongType, StringType, DoubleType, IntegerType,
)

# ----------------------------------------------------------------------------
# S3 LOCATIONS
# ----------------------------------------------------------------------------
# NOTE ON URI SCHEME / AUTH: this project authenticates to S3 via a Unity
# Catalog EXTERNAL LOCATION (backed by a Storage Credential / IAM role
# registered in UC), not a manually-configured access key or instance
# profile. With a UC external location, Databricks vends short-lived S3
# credentials automatically for any code path (Spark, dbutils.fs, Python) —
# there is nothing to set in the cluster's Spark config. Use the plain
# "s3://" scheme (not "s3a://"); UC's credential vending is wired to that
# scheme, and every path below must fall under the prefix your external
# location was registered against. The cluster must be attached to a Unity
# Catalog metastore and run in a UC-compatible access mode (Shared or
# Single User / "Assigned"), and the running user / service principal needs
# READ FILES (and WRITE FILES, for the output roots) granted on the
# external location — see the README's "S3 authentication" section.
RAW_BUCKET = "research-s20426"
RAW_ROOT = f"s3://{RAW_BUCKET}"

# Where cleaned, ETL-stage Parquet tables land.
ETL_OUTPUT_ROOT = f"s3://{RAW_BUCKET}/etl_output_root"

# Where the feature-engineering stage writes node/edge feature snapshots,
# manifests, and dataset stats (consumed downstream by model training).
FE_OUTPUT_ROOT = f"s3://{RAW_BUCKET}/tgnn_dataset_v2"

# Local scratch space used only for tar.gz extraction. On a classic cluster
# node-local disk (e.g. /local_disk0) would be faster, but Serverless
# compute generally doesn't expose /local_disk0 at all, so this defaults to
# /tmp, which is available on both. This should NOT point at DBFS/S3 —
# extraction does many small file writes, which is slow and expensive
# against object storage.

LOCAL_EXTRACT_ROOT = "/tmp/ms_extract"
# ----------------------------------------------------------------------------
# TIME BUCKETING
# ----------------------------------------------------------------------------
# Milliseconds per time bucket. ALL tables (resource, rtqps, callgraph) must
# use this same value when deriving t_idx, or joins between tables will be
# silently misaligned. The original notebooks used 30_000 in ETL.ipynb but
# 60_000 in Feature_engineering_and_model_building.ipynb — pick one value
# here and both stages will stay consistent.
TIME_BUCKET_MS = 60_000  # 1 minute

# ----------------------------------------------------------------------------
# TRAIN / VAL / TEST SPLIT (in t_idx units, i.e. minutes since trace start)
# ----------------------------------------------------------------------------
TRAIN_END = 650
VAL_END = 700

# ----------------------------------------------------------------------------
# SCALING
# ----------------------------------------------------------------------------
IQR_FLOOR = 1e-8  # robust-scaler denominator floor to avoid divide-by-zero

# ----------------------------------------------------------------------------
# SPARK RUNTIME SETTINGS
# ----------------------------------------------------------------------------
# On Databricks the cluster (driver/executor memory, core count) is set at
# the cluster level, NOT via SparkSession.builder in notebook code — a
# manually-built SparkSession is ignored on Databricks clusters. These are
# just the *session-level* conf knobs it's still safe to tune from a notebook.
#
# On Serverless compute / some Unity-Catalog-governed clusters, most SQL
# execution confs (AQE, Parquet vectorized reader, compression codec, etc.)
# are locked and managed automatically — Databricks already runs AQE and
# tuned Parquet I/O there by default, so there's nothing to configure.
# Only shuffle.partitions and maxPartitionBytes are kept here since those
# are the two that are actually user-overridable across cluster types;
# spark_utils.apply_spark_conf() still skips gracefully if even these are
# locked on a given cluster.
SPARK_CONF = {
    "spark.sql.shuffle.partitions": "480",
    "spark.sql.files.maxPartitionBytes": str(128 * 1024 * 1024),   # 128 MB
}

# Number of output files to coalesce ETL Parquet writes to. Keep partitions
# in the ~128-256MB range; tune based on actual data volume per table.
ETL_OUTPUT_PARTITIONS = 480

# ----------------------------------------------------------------------------
# RAW CSV SCHEMAS (explicit — never use inferSchema on multi-GB CSVs)
# ----------------------------------------------------------------------------
SCHEMA_RTQPS = StructType([
    StructField("_c0", IntegerType(), True),         # unnamed pandas index
    StructField("timestamp", LongType(), True),
    StructField("msname", StringType(), True),
    StructField("msinstanceid", StringType(), True),
    StructField("metric", StringType(), True),       # e.g. "providerRPC_MCR"
    StructField("value", DoubleType(), True),
])

SCHEMA_RESOURCE = StructType([
    StructField("_c0", IntegerType(), True),
    StructField("msname", StringType(), True),
    StructField("msinstanceid", StringType(), True),
    StructField("nodeid", StringType(), True),
    StructField("instance_cpu_usage", DoubleType(), True),
    StructField("instance_memory_usage", DoubleType(), True),
    StructField("timestamp", LongType(), True),
])

SCHEMA_CALLGRAPH = StructType([
    StructField("_c0", IntegerType(), True),
    StructField("traceid", StringType(), True),
    StructField("timestamp", LongType(), True),
    StructField("rpcid", StringType(), True),   # call-chain position
    StructField("um", StringType(), True),      # upstream / callee
    StructField("rpctype", StringType(), True), # mc / rpc / http / mq
    StructField("dm", StringType(), True),      # downstream / caller
    StructField("interface", StringType(), True),
    StructField("rt", DoubleType(), True),      # response time
])

# ----------------------------------------------------------------------------
# MISSING VALUE IMPUTATION
# ----------------------------------------------------------------------------
# Raw (pre-aggregation) columns imputed with train-fit mode before any
# per-msname aggregation happens. RTQ's raw columns depend on the actual
# metric names in your data (MCR_COLS_DEFAULT / RT_COLS_DEFAULT below), so
# those are combined into the imputation column list at runtime in the FE
# notebook rather than hardcoded here.
RES_IMPUTE_COLS = ["cpu_utilization", "memory_utilization"]

# ----------------------------------------------------------------------------
# FEATURE ENGINEERING COLUMN LISTS
# ----------------------------------------------------------------------------
RES_AGG_COLS = [
    "cpu_mode", "cpu_p95", "cpu_overload_count",
    "memory_mode", "memory_p95", "memory_overload_count",
    "num_containers",
]

# RTQ metrics are pivoted from a long `metric` column at ETL time. These are
# the two metric families the FE stage expects to find as wide columns.
# Adjust MCR_COLS / RT_COLS to match the actual distinct `metric` values in
# your dataset (printed by the ETL notebook's diagnostic cell).
MCR_COLS_DEFAULT = ["providerRPC_MCR", "consumerRPC_MCR"]
RT_COLS_DEFAULT = ["providerRPC_RT", "consumerRPC_RT"]

EDGE_LOG_COLS = ["rt_log_mode", "call_count_log"]
