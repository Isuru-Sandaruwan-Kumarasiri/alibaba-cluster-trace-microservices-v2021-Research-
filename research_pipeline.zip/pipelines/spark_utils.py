"""
spark_utils.py
==============
Small helpers for working with the Databricks-managed SparkSession.

On Databricks you never call SparkSession.builder(...).getOrCreate() with
memory/core settings yourself — the cluster is already running Spark and
`spark` is injected into every notebook. Calling .getOrCreate() again just
hands you back the same session; per-cluster memory/core config belongs in
the cluster's Spark Config UI, not notebook code. What notebook code *can*
still do is set session-level SQL/runtime conf (shuffle partitions, arrow,
parquet options) — that's what apply_spark_conf does.
"""

from config import SPARK_CONF


def get_spark():
    """
    Return the active Databricks-managed SparkSession.

    Import and call this from notebooks/scripts instead of referencing the
    Databricks-injected `spark` global directly, so the same code also runs
    (against a local SparkSession) outside Databricks, e.g. in unit tests.
    """
    from pyspark.sql import SparkSession
    return SparkSession.builder.getOrCreate()


def apply_spark_conf(spark, overrides: dict | None = None):
    """
    Apply the shared SPARK_CONF (config.py) to the given session, optionally
    merged with caller-supplied overrides.

    Applies each key individually and swallows failures for any single key
    that the cluster rejects (e.g. CONFIG_NOT_AVAILABLE for configs that are
    static / cluster-startup-only on some Databricks runtimes, access modes,
    or Photon-enabled clusters) — one unsupported key shouldn't block every
    other conf from being applied. Skipped keys are printed so you can see
    what didn't take effect.

    Parameters
    ----------
    spark : SparkSession
    overrides : dict, optional
        Extra / override key-value conf pairs applied after SPARK_CONF.
    """
    conf = dict(SPARK_CONF)
    if overrides:
        conf.update(overrides)

    skipped = []
    for key, value in conf.items():
        try:
            spark.conf.set(key, value)
        except Exception as e:
            skipped.append((key, str(e).splitlines()[0]))

    if skipped:
        print("Skipped unsupported/static Spark conf keys on this cluster (this is usually fine):")
        for key, msg in skipped:
            print(f"  - {key}: {msg}")

    return spark


def show_cluster_info(spark):
    """
    Print a quick sanity check of the session Spark is running under.

    Deliberately avoids spark.sparkContext / any JVM-level SparkContext
    attribute access — that's blocked outright on Serverless compute
    (JVM_ATTRIBUTE_NOT_SUPPORTED). Everything here goes through the public,
    serverless-safe SparkSession/session-conf API instead.
    """
    print(f"Spark version      : {spark.version}")
    try:
        print(f"shuffle.partitions  : {spark.conf.get('spark.sql.shuffle.partitions')}")
    except Exception:
        # Informational only — never let this block pipeline execution.
        pass
