"""
feature_engineering.py
=======================
Stage 2 of the pipeline: turn the ETL Parquet tables (resource, rtqps,
callgraph_clean) into a train/val/test-split, leakage-safe node/edge feature
dataset for downstream graph/temporal-GNN model training, written to
config.FE_OUTPUT_ROOT.

Design notes carried over (and fixed) from the original notebook:
  - All scalers (robust scaler, StringIndexer for rpctype) are FIT ON TRAIN
    ONLY and applied to val/test — this is the load-bearing anti-leakage
    rule in this module. Every fit_* function takes exactly one DataFrame
    (train); every apply_* function takes stats/model + any split.
  - t_idx is assumed already present and consistent across tables (added by
    etl.py using the shared TIME_BUCKET_MS) — this stage does not recompute
    it, unlike the original notebook which redundantly re-derived t_idx here
    at a different bucket size than ETL used.
"""

import json

from pyspark.sql import functions as F
from pyspark.sql import Window
from pyspark.sql.types import LongType
from pyspark.sql.functions import broadcast
from pyspark.ml.feature import StringIndexer
from pyspark.ml import Pipeline

from config import (
    TRAIN_END, VAL_END, IQR_FLOOR, FE_OUTPUT_ROOT,
    RES_AGG_COLS, EDGE_LOG_COLS,
)


# ----------------------------------------------------------------------------
# Train / val / test split
# ----------------------------------------------------------------------------
def temporal_split(df, train_end: int = TRAIN_END, val_end: int = VAL_END):
    train = df.filter(F.col("t_idx") < train_end)
    val = df.filter((F.col("t_idx") >= train_end) & (F.col("t_idx") < val_end))
    test = df.filter(F.col("t_idx") >= val_end)
    return train, val, test


# ----------------------------------------------------------------------------
# Robust scaler (median / IQR), fit-on-train-only
# ----------------------------------------------------------------------------
def compute_robust_stats(df, col_name: str, iqr_floor: float = IQR_FLOOR):
    q1, q2, q3 = df.approxQuantile(col_name, [0.25, 0.5, 0.75], 0.01)
    iqr = q3 - q1
    if iqr < iqr_floor:
        iqr = 1.0
    return float(q2), float(iqr)


def fit_robust_scaler(train_df, cols):
    """Fit median/IQR stats on the TRAIN split only. Returns a plain dict so
    it can be logged / written to the manifest and re-applied later without
    re-fitting."""
    stats = {}
    for col in cols:
        q2, iqr = compute_robust_stats(train_df, col)
        stats[col] = {"q2": q2, "iqr": iqr}
        print(f"  {col:42s}  median={q2:.4f}  iqr={iqr:.4f}")
    return stats


def apply_robust_scaler(df, stats: dict, suffix: str = "_rs"):
    """Apply pre-fitted median/IQR stats to any split (train, val, or test)."""
    for col, s in stats.items():
        df = df.withColumn(
            f"{col}{suffix}",
            (F.col(col) - F.lit(s["q2"])) / F.lit(s["iqr"]),
        )
    return df


# ----------------------------------------------------------------------------
# Missing value imputation — median, fit-on-train-only
# ----------------------------------------------------------------------------
def fit_median_imputer(train_df, cols, relative_error: float = 0.001):
    """
    Compute the median (50th percentile) of each column on the TRAIN split
    only, via Spark's approxQuantile. Returns a plain {col: median_value}
    dict, directly usable with DataFrame.fillna(). If a column is entirely
    null in train (no median to compute), falls back to 0.0 and prints a
    warning rather than failing.

    relative_error controls the approxQuantile accuracy/speed tradeoff —
    0.001 is accurate to within ~0.1% of the true rank on large data while
    staying far cheaper than an exact median (which would require a full
    sort). Use 0.0 for an exact median if the column is small enough.
    """
    stats = {}
    for c in cols:
        non_null = train_df.filter(F.col(c).isNotNull())
        quantiles = non_null.approxQuantile(c, [0.5], relative_error)
        if not quantiles:
            print(f"  WARNING: '{c}' has no non-null values in train — falling back to 0.0")
            median_val = 0.0
        else:
            median_val = quantiles[0]
        stats[c] = median_val
        print(f"  {c:30s} median={median_val}")
    return stats


def apply_median_imputer(df, stats: dict):
    """Apply pre-fitted per-column median values (from fit_median_imputer)
    to any split (train, val, or test) — fills nulls only, does not touch
    non-null values."""
    return df.fillna(stats)


# Mode imputer kept for reference/backwards compatibility — no longer used
# by the pipeline (see fit_median_imputer / apply_median_imputer above).
def fit_mode_imputer(train_df, cols):
    stats = {}
    for c in cols:
        mode_row = (
            train_df.filter(F.col(c).isNotNull())
            .groupBy(c)
            .count()
            .orderBy(F.desc("count"))
            .first()
        )
        if mode_row is None:
            print(f"  WARNING: '{c}' has no non-null values in train — falling back to 0.0")
            mode_val = 0.0
        else:
            mode_val = mode_row[c]
        stats[c] = mode_val
        print(f"  {c:30s} mode={mode_val}")
    return stats


def apply_mode_imputer(df, stats: dict):
    return df.fillna(stats)


# ----------------------------------------------------------------------------
# Global node index (msname-level), built across ALL splits so every node
# gets a stable id regardless of which split it first appears in
# ----------------------------------------------------------------------------
def build_node_index(spark, res_splits, cg_splits, output_root: str = FE_OUTPUT_ROOT):
    """
    res_splits : (res_train, res_val, res_test)
    cg_splits  : (cg_train, cg_val, cg_test)   with columns UM, DM
    """
    res_train, res_val, res_test = res_splits
    cg_train, cg_val, cg_test = cg_splits

    all_names = (
        res_train.select(F.col("msname").alias("node_key"))
        .union(res_val.select(F.col("msname").alias("node_key")))
        .union(res_test.select(F.col("msname").alias("node_key")))
        .union(cg_train.select(F.col("UM").alias("node_key")))
        .union(cg_val.select(F.col("UM").alias("node_key")))
        .union(cg_test.select(F.col("UM").alias("node_key")))
        .union(cg_train.select(F.col("DM").alias("node_key")))
        .union(cg_val.select(F.col("DM").alias("node_key")))
        .union(cg_test.select(F.col("DM").alias("node_key")))
        .distinct()
    )

    node_index = (
        all_names
        .orderBy("node_key")
        .withColumn("node_id", F.monotonically_increasing_id().cast(LongType()))
    )

    out_path = f"{output_root}/node_index"
    node_index.write.mode("overwrite").parquet(out_path)
    print(f"\u2713 wrote node_index -> {out_path}")
    return spark.read.parquet(out_path)


# ----------------------------------------------------------------------------
# Resource feature engineering
# ----------------------------------------------------------------------------
def aggregate_res_to_msname(res_df):
    """
    NOTE: uses statistical mode (most frequent value), not mean/max/stddev,
    as the central-tendency stat per (msname, t_idx) group — per explicit
    instruction. This consolidates what was previously 3 separate stats
    (mean, max, stddev) per metric into a single `_mode` column each, since
    computing "mode" three different ways would just repeat the same value.
    Requires pyspark.sql.functions.mode, available Spark 3.4+.
    """
    return (
        res_df.groupBy("msname", "t_idx").agg(
            F.mode("cpu_utilization").alias("cpu_mode"),
            F.percentile_approx("cpu_utilization", 0.95).alias("cpu_p95"),
            F.sum(F.when(F.col("cpu_utilization") > 0.8, 1).otherwise(0)).alias("cpu_overload_count"),
            F.mode("memory_utilization").alias("memory_mode"),
            F.percentile_approx("memory_utilization", 0.95).alias("memory_p95"),
            F.sum(F.when(F.col("memory_utilization") > 0.8, 1).otherwise(0)).alias("memory_overload_count"),
            F.countDistinct("msinstanceid").alias("num_containers"),
        )
        .fillna(0.0)
    )


ROLLING_COLS = [
    "cpu_rolling_mean", "cpu_rolling_std", "cpu_delta",
    "memory_rolling_mean", "memory_rolling_std", "memory_delta",
]


def add_temporal_features(df):
    """Rolling window (5 steps, causal) + first-difference features, computed
    on the already-scaled `*_mode_rs` columns (see aggregate_res_to_msname).
    The rolling mean/std here are Spark window functions over that mode
    signal, not a re-aggregation of raw samples, so they're left as
    mean/std rather than also switched to mode."""
    window_5 = Window.partitionBy("msname").orderBy("t_idx").rowsBetween(-4, 0)
    lag_window = Window.partitionBy("msname").orderBy("t_idx")

    df = df.withColumn("cpu_rolling_mean", F.avg("cpu_mode_rs").over(window_5))
    df = df.withColumn("cpu_rolling_std", F.stddev("cpu_mode_rs").over(window_5))
    df = df.withColumn("_cpu_lag1", F.lag("cpu_mode_rs", 1).over(lag_window))
    df = df.withColumn(
        "cpu_delta",
        F.when(F.col("_cpu_lag1").isNull(), 0.0).otherwise(F.col("cpu_mode_rs") - F.col("_cpu_lag1")),
    ).drop("_cpu_lag1")

    df = df.withColumn("memory_rolling_mean", F.avg("memory_mode_rs").over(window_5))
    df = df.withColumn("memory_rolling_std", F.stddev("memory_mode_rs").over(window_5))
    df = df.withColumn("_mem_lag1", F.lag("memory_mode_rs", 1).over(lag_window))
    df = df.withColumn(
        "memory_delta",
        F.when(F.col("_mem_lag1").isNull(), 0.0).otherwise(F.col("memory_mode_rs") - F.col("_mem_lag1")),
    ).drop("_mem_lag1")

    # fill nulls introduced by rolling stddev on single-row windows
    return df.fillna(0.0, subset=ROLLING_COLS)


def add_cyclical_time_features(df, period: int = 1440):
    """sin/cos encoding of time-of-day, assuming t_idx is in minutes and
    `period` is minutes-per-day (1440). Adjust if TIME_BUCKET_MS != 60_000."""
    return (
        df.withColumn("t_sin", F.sin(2 * 3.141592653589793 * (F.col("t_idx") % period) / period))
        .withColumn("t_cos", F.cos(2 * 3.141592653589793 * (F.col("t_idx") % period) / period))
    )


# ----------------------------------------------------------------------------
# RTQ feature engineering
# ----------------------------------------------------------------------------
def aggregate_rtq_to_msname(rtq_df, mcr_cols, rt_cols):
    """MCR (request/throughput count) columns are summed — a legitimate
    total, not a central-tendency stat, so left as-is. RT (latency) columns
    use mode instead of max, per explicit instruction."""
    mcr_aggs = [F.sum(c).alias(c) for c in mcr_cols if c in rtq_df.columns]
    rt_aggs = [F.mode(c).alias(c) for c in rt_cols if c in rtq_df.columns]
    return rtq_df.groupBy("msname", "t_idx").agg(*mcr_aggs, *rt_aggs).fillna(0.0)


def fix_and_log_rtq(df, rt_cols, all_cols):
    """Replace true-zero RT (meaning <1ms, not "no data") with a small
    epsilon, then log1p every RTQ column to tame the heavy-tailed
    distribution before robust scaling."""
    for col in rt_cols:
        if col in df.columns:
            df = df.withColumn(col, F.when(F.col(col) == 0, 0.001).otherwise(F.col(col)))
    for col in all_cols:
        if col in df.columns:
            df = df.withColumn(f"{col}_log", F.log1p(F.col(col)))
    return df


# ----------------------------------------------------------------------------
# Build final node feature table (joins resource + rtq at msname/t_idx, then
# attaches node_id)
# ----------------------------------------------------------------------------
def build_node_features(res_ms_df, rtq_ms_df, node_index_df, rtq_scaled_cols, all_node_feature_cols):
    joined = (
        res_ms_df.alias("r")
        .join(
            rtq_ms_df.select("msname", "t_idx", *rtq_scaled_cols).alias("q"),
            on=["msname", "t_idx"], how="left",
        )
        .fillna(0.0)
    )
    with_id = joined.join(
        broadcast(node_index_df.select(F.col("node_key").alias("msname"), F.col("node_id"))),
        on="msname", how="left",
    )
    return with_id.select("node_id", "msname", "t_idx", *all_node_feature_cols)


# ----------------------------------------------------------------------------
# Edge feature engineering (call graph)
# ----------------------------------------------------------------------------
def clean_and_aggregate_cg(cg_df):
    """
    NOTE: uses statistical mode (most frequent value) for response time,
    not mean/max/stddev, per explicit instruction — consolidated to a
    single `rt_mode` column instead of the previous rt_mean/rt_max/rt_std
    trio. call_count is a legitimate total (not central-tendency), left
    as-is.
    """
    return (
        cg_df
        .filter(F.col("rt") > 0)  # UM-side record only; DM-side mirrors with rt<=0
        .groupBy("UM", "DM", "t_idx", "rpctype")
        .agg(
            F.mode("rt").alias("rt_mode"),
            F.count("*").alias("call_count"),
        )
        .fillna(0.0)
        .withColumn("rt_log_mode", F.log1p(F.col("rt_mode")))
        .withColumn("call_count_log", F.log1p(F.col("call_count")))
    )


def fit_rpctype_encoder(cg_clean_train):
    pipeline = Pipeline(stages=[
        StringIndexer(inputCol="rpctype", outputCol="rpctype_idx", handleInvalid="keep")
    ])
    return pipeline.fit(cg_clean_train)


def build_edge_features(cg_df, node_index_df, edge_feature_cols):
    node_lookup_src = node_index_df.select(F.col("node_key"), F.col("node_id").alias("src_node_id"))
    node_lookup_dst = node_index_df.select(F.col("node_key"), F.col("node_id").alias("dst_node_id"))

    with_src = (
        cg_df.join(broadcast(node_lookup_src), on=cg_df["UM"] == node_lookup_src["node_key"], how="left")
        .drop("node_key")
    )
    with_dst = (
        with_src.join(broadcast(node_lookup_dst), on=with_src["DM"] == node_lookup_dst["node_key"], how="left")
        .drop("node_key")
    )
    return with_dst.select("src_node_id", "dst_node_id", "t_idx", *edge_feature_cols)


# ----------------------------------------------------------------------------
# Output writers: snapshots (partitioned by t_idx), manifests, dataset stats
# ----------------------------------------------------------------------------
def write_snapshots(node_feat_df, edge_feat_df, split_name: str, output_root: str = FE_OUTPUT_ROOT):
    node_cols = [c for c in node_feat_df.columns if c != "t_idx"]
    edge_cols = [c for c in edge_feat_df.columns if c != "t_idx"]

    (
        node_feat_df.select("t_idx", *node_cols)
        .write.mode("overwrite").partitionBy("t_idx")
        .option("compression", "snappy")
        .parquet(f"{output_root}/snapshots/{split_name}/nodes")
    )
    (
        edge_feat_df.select("t_idx", *edge_cols)
        .write.mode("overwrite").partitionBy("t_idx")
        .option("compression", "snappy")
        .parquet(f"{output_root}/snapshots/{split_name}/edges")
    )
    print(f"\u2713 wrote {split_name} snapshots -> {output_root}/snapshots/{split_name}/{{nodes,edges}}")


def write_manifest(spark, node_feat_df, split_name: str, output_root: str = FE_OUTPUT_ROOT):
    t_indices = (
        node_feat_df.select("t_idx").distinct().orderBy("t_idx")
        .toPandas()["t_idx"].astype(int).tolist()
    )
    manifest = {
        "split": split_name,
        "t_indices": t_indices,
        "count": len(t_indices),
        "nodes_path": f"{output_root}/snapshots/{split_name}/nodes",
        "edges_path": f"{output_root}/snapshots/{split_name}/edges",
    }
    mdf = spark.createDataFrame([(json.dumps(manifest, indent=2),)], ["json"])
    mdf.coalesce(1).write.mode("overwrite").text(f"{output_root}/manifests/{split_name}")
    print(f"[{split_name}] manifest: {len(t_indices)} snapshots "
          f"(t={t_indices[0]} -> t={t_indices[-1]})")
    return manifest


def write_dataset_stats(spark, node_index_df, all_node_feature_cols, edge_feature_cols,
                         split_manifests: dict, output_root: str = FE_OUTPUT_ROOT):
    stats = {
        "version": "v2",
        "graph_level": "msname (microservice)",
        "num_nodes": node_index_df.count(),
        "num_node_features": len(all_node_feature_cols),
        "num_edge_features": len(edge_feature_cols),
        "node_feature_names": all_node_feature_cols,
        "edge_feature_names": edge_feature_cols,
        "train_t_range": [split_manifests["train"]["t_indices"][0], split_manifests["train"]["t_indices"][-1]],
        "val_t_range": [split_manifests["val"]["t_indices"][0], split_manifests["val"]["t_indices"][-1]],
        "test_t_range": [split_manifests["test"]["t_indices"][0], split_manifests["test"]["t_indices"][-1]],
        "s3_root": output_root,
    }
    sdf = spark.createDataFrame([(json.dumps(stats, indent=2),)], ["json"])
    sdf.coalesce(1).write.mode("overwrite").text(f"{output_root}/dataset_stats")
    print(f"\u2713 wrote dataset_stats -> {output_root}/dataset_stats")
    return stats
