"""
etl.py
======
Stage 1 of the pipeline: turn the raw Alibaba cluster-trace-microservices-v2021
CSVs (already extracted from tar.gz onto local disk by s3_extract_utils) into
clean, schema-enforced Parquet tables written to S3, ready for the feature
engineering stage.

Produces three tables under config.ETL_OUTPUT_ROOT:
  - resource/            per-instance CPU/memory usage, one row per sample
  - rtqps/                per-msname request/latency metrics, pivoted wide
  - callgraph_clean/      per-call trace edges, minimally cleaned

Each table gets a `t_idx` column: the time bucket index at TIME_BUCKET_MS
resolution, consistent across all three tables so later joins line up.
"""

import os
import time
import shutil

from pyspark.sql import functions as F

from config import (
    SCHEMA_RTQPS, SCHEMA_RESOURCE, SCHEMA_CALLGRAPH,
    TIME_BUCKET_MS, ETL_OUTPUT_ROOT, ETL_OUTPUT_PARTITIONS,
)


# ----------------------------------------------------------------------------
# Generic helpers
# ----------------------------------------------------------------------------
def add_t_idx(df):
    """Attach the shared time-bucket index. Must be used identically by every
    table so joins downstream are correctly aligned."""
    return df.withColumn("t_idx", (F.col("timestamp") / F.lit(TIME_BUCKET_MS)).cast("int"))


def write_parquet(spark, df, table_name: str, partitions: int = ETL_OUTPUT_PARTITIONS):
    """
    Write a cleaned DataFrame to its ETL output location as Parquet,
    overwriting any previous version. Runs a cheap `.limit(3).collect()`
    sanity check first so an empty/broken upstream read fails loudly here
    rather than silently producing an empty table.
    """
    out_path = f"{ETL_OUTPUT_ROOT}/{table_name}"

    sample = df.limit(3).collect()
    if not sample:
        raise ValueError(f"{table_name}: DataFrame is empty before write — check upstream read/transform")
    print(f"  sample row: {sample[0].asDict()}")

    t0 = time.time()
    (
        df.repartition(partitions)
        .write
        .mode("overwrite")
        .option("compression", "snappy")
        .parquet(out_path)
    )
    elapsed = time.time() - t0
    print(f"  \u2713 wrote {table_name} -> {out_path} ({elapsed / 60:.1f} min)")
    return out_path


# ----------------------------------------------------------------------------
# MSRTQps
# ----------------------------------------------------------------------------
def read_rtqps_raw(spark, local_csv_dir: str):
    return (
        spark.read
        .option("header", "true")
        .option("mode", "DROPMALFORMED")
        .option("nullValue", "")
        .schema(SCHEMA_RTQPS)
        .csv(local_csv_dir)
    )


def transform_rtqps(rtqps_long):
    """
    Aggregate instance-level rows to msname level (mean across instances),
    then pivot the long `metric` column into one wide column per metric.
    """
    wide = (
        rtqps_long
        .drop("_c0")
        .dropna(subset=["timestamp", "metric", "value"])
        .groupBy("timestamp", "msname", "metric")
        .agg(F.mean("value").alias("value"))
        .groupBy("timestamp", "msname")
        .pivot("metric")
        .agg(F.first("value"))
    )
    return add_t_idx(wide)


# ----------------------------------------------------------------------------
# MSResource
# ----------------------------------------------------------------------------
def read_resource_raw(spark, local_csv_dir: str):
    return (
        spark.read
        .option("header", "true")
        .option("mode", "DROPMALFORMED")
        .option("nullValue", "")
        .schema(SCHEMA_RESOURCE)
        .csv(local_csv_dir)
    )


def transform_resource(resource_raw):
    cleaned = (
        resource_raw
        .drop("_c0")
        .dropna(subset=["timestamp", "msname"])
        .withColumnRenamed("instance_cpu_usage", "cpu_utilization")
        .withColumnRenamed("instance_memory_usage", "memory_utilization")
    )
    return add_t_idx(cleaned)


# ----------------------------------------------------------------------------
# MSCallGraph
# ----------------------------------------------------------------------------
def read_callgraph_raw(spark, local_csv_dir: str):
    return (
        spark.read
        .option("header", "true")
        .option("mode", "DROPMALFORMED")
        .option("nullValue", "")
        .schema(SCHEMA_CALLGRAPH)
        .csv(local_csv_dir)
    )


def transform_callgraph(cg_raw):
    """
    Minimal ETL-stage cleaning only. Heavier aggregation (rt > 0 filtering,
    per-edge-per-minute aggregation, log transforms) happens in the feature
    engineering stage since it depends on train/val/test split boundaries
    and should be re-derivable without re-reading raw CSVs.
    """
    cleaned = (
        cg_raw
        .drop("_c0")
        .dropna(subset=["timestamp", "um", "dm"])
        .withColumnRenamed("um", "UM")
        .withColumnRenamed("dm", "DM")
    )
    return add_t_idx(cleaned)


# ----------------------------------------------------------------------------
# Orchestration (called from notebooks/01_etl_pipeline.py)
# ----------------------------------------------------------------------------
def run_rtqps_etl(spark, local_csv_dir: str):
    print("\n--- MSRTQps ---")
    raw = read_rtqps_raw(spark, local_csv_dir)
    print("Distinct metric values:")
    raw.select("metric").distinct().show(30, truncate=False)
    wide = transform_rtqps(raw)
    wide.printSchema()
    return write_parquet(spark, wide, "rtqps")


def run_resource_etl(spark, local_csv_dir: str):
    print("\n--- MSResource ---")
    raw = read_resource_raw(spark, local_csv_dir)
    cleaned = transform_resource(raw)
    cleaned.printSchema()
    return write_parquet(spark, cleaned, "resource")


def run_callgraph_etl(spark, local_csv_dir: str):
    print("\n--- MSCallGraph ---")
    raw = read_callgraph_raw(spark, local_csv_dir)
    cleaned = transform_callgraph(raw)
    cleaned.printSchema()
    return write_parquet(spark, cleaned, "callgraph_clean")
