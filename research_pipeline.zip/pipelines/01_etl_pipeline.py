# Databricks notebook source
# MAGIC %md
# MAGIC # ETL Pipeline — Alibaba Microservices Trace Data
# MAGIC Extracts `MSResource`, `MSRTQps`, `MSCallGraph` tar.gz archives from S3,
# MAGIC reads the CSVs with an explicit schema, cleans/transforms each table, and
# MAGIC writes clean Parquet back to S3 (`config.ETL_OUTPUT_ROOT`).
# MAGIC
# MAGIC **Repo setup**: this notebook expects `config.py`, `etl.py`,
# MAGIC `s3_extract_utils.py`, and `spark_utils.py` to sit alongside it (e.g. in the
# MAGIC same Databricks Repo folder). If they're one directory up, uncomment the
# MAGIC `sys.path` line below.

# COMMAND ----------

import sys, os
# sys.path.append(os.path.abspath(".."))  # uncomment if modules live one level up

from config import RAW_ROOT, ETL_OUTPUT_ROOT
from spark_utils import get_spark, apply_spark_conf, show_cluster_info
from s3_extract_utils import extract_table_from_s3, cleanup_local_extract
import etl

# COMMAND ----------

# MAGIC %md ### Widgets — override paths per-environment without editing config.py

# COMMAND ----------

dbutils.widgets.text("raw_root", RAW_ROOT, "Raw S3 root")
dbutils.widgets.text("etl_output_root", ETL_OUTPUT_ROOT, "ETL output S3 root")

raw_root = dbutils.widgets.get("raw_root")
etl_output_root = dbutils.widgets.get("etl_output_root")

print(f"raw_root        = {raw_root}")
print(f"etl_output_root = {etl_output_root}")

# COMMAND ----------

spark = get_spark()
apply_spark_conf(spark)
show_cluster_info(spark)

# COMMAND ----------

# MAGIC %md ## MSRTQps

# COMMAND ----------

rtqps_csv_dir = extract_table_from_s3("MSRTQps", dbutils)
rtqps_path = etl.run_rtqps_etl(spark, rtqps_csv_dir)

# COMMAND ----------

# MAGIC %md ## MSResource

# COMMAND ----------

resource_csv_dir = extract_table_from_s3("MSResource", dbutils)
resource_path = etl.run_resource_etl(spark, resource_csv_dir)

# COMMAND ----------

# MAGIC %md ## MSCallGraph

# COMMAND ----------

callgraph_csv_dir = extract_table_from_s3("MSCallGraph", dbutils)
callgraph_path = etl.run_callgraph_etl(spark, callgraph_csv_dir)

# COMMAND ----------

# MAGIC %md ## Cleanup local scratch space

# COMMAND ----------

cleanup_local_extract()

# COMMAND ----------

# MAGIC %md ## Sanity check — read back what was just written

# COMMAND ----------

for name, path in [("resource", resource_path), ("rtqps", rtqps_path), ("callgraph_clean", callgraph_path)]:
    df = spark.read.parquet(path)
    n = df.count()
    print(f"{'\u2713' if n > 0 else '\u2717'} {name:16s} {n:>12,} rows   columns={df.columns}")

print("\nETL stage complete. Outputs ready for 02_feature_engineering_pipeline.py")