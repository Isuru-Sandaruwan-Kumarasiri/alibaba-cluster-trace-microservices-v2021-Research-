# Databricks notebook source
# MAGIC %md
# MAGIC # Feature Engineering Pipeline — TGNN Node/Edge Dataset
# MAGIC Reads the ETL-stage Parquet tables (`resource`, `rtqps`, `callgraph_clean`),
# MAGIC applies a leakage-safe train/val/test split, fits scalers/encoders on TRAIN
# MAGIC ONLY, builds node and edge feature tables, and writes partitioned snapshot
# MAGIC Parquet + manifests + dataset stats to `config.FE_OUTPUT_ROOT`.
# MAGIC
# MAGIC Run **after** `01_etl_pipeline.py` has completed successfully.

# COMMAND ----------

import sys, os
# sys.path.append(os.path.abspath(".."))  # uncomment if modules live one level up

from config import (
    ETL_OUTPUT_ROOT, FE_OUTPUT_ROOT, TRAIN_END, VAL_END,
    RES_AGG_COLS, MCR_COLS_DEFAULT, RT_COLS_DEFAULT, EDGE_LOG_COLS,
    RES_IMPUTE_COLS,
)
from spark_utils import get_spark, apply_spark_conf, show_cluster_info
import feature_engineering as fe

# COMMAND ----------

# MAGIC %md ### Widgets

# COMMAND ----------

dbutils.widgets.text("etl_output_root", ETL_OUTPUT_ROOT, "ETL output S3 root (input)")
dbutils.widgets.text("fe_output_root", FE_OUTPUT_ROOT, "Feature-engineering S3 root (output)")
dbutils.widgets.text("train_end", str(TRAIN_END), "TRAIN_END (t_idx)")
dbutils.widgets.text("val_end", str(VAL_END), "VAL_END (t_idx)")

etl_output_root = dbutils.widgets.get("etl_output_root")
fe_output_root = dbutils.widgets.get("fe_output_root")
train_end = int(dbutils.widgets.get("train_end"))
val_end = int(dbutils.widgets.get("val_end"))

print(f"etl_output_root = {etl_output_root}")
print(f"fe_output_root  = {fe_output_root}")
print(f"train_end={train_end}  val_end={val_end}")

# COMMAND ----------

spark = get_spark()
apply_spark_conf(spark)
show_cluster_info(spark)

# COMMAND ----------

# MAGIC %md ## Part 1 — Load ETL Output

# COMMAND ----------

res = spark.read.parquet(f"{etl_output_root}/resource")
rtq = spark.read.parquet(f"{etl_output_root}/msrtqps")
cg = spark.read.parquet(f"{etl_output_root}/callgraph_1")

print("res schema:"); res.printSchema()
print("rtq schema:"); rtq.printSchema()
print("cg  schema:"); cg.printSchema()

# COMMAND ----------

cg.columns

# COMMAND ----------

# MAGIC %md
# MAGIC #### Confirm the RTQ metric columns actually present after ETL's pivot
# MAGIC `MCR_COLS_DEFAULT` / `RT_COLS_DEFAULT` in config.py are placeholders —
# MAGIC update them to match whatever this prints if your dataset's metric names
# MAGIC differ.

# COMMAND ----------

rtq_metric_cols = [c for c in rtq.columns if c not in ("timestamp", "msname", "t_idx")]
print("RTQ wide columns available:", rtq_metric_cols)

mcr_cols = [c for c in MCR_COLS_DEFAULT if c in rtq_metric_cols] or \
    [c for c in rtq_metric_cols if "MCR" in c]
rt_cols = [c for c in RT_COLS_DEFAULT if c in rtq_metric_cols] or \
    [c for c in rtq_metric_cols if c not in mcr_cols]

print("Using MCR_COLS:", mcr_cols)
print("Using RT_COLS :", rt_cols)
all_rtq_cols = mcr_cols + rt_cols

# COMMAND ----------

# MAGIC %md ## Part 2 — Temporal Split (leakage boundary starts here)

# COMMAND ----------

res_train, res_val, res_test = fe.temporal_split(res, train_end, val_end)
rtq_train, rtq_val, rtq_test = fe.temporal_split(rtq, train_end, val_end)
cg_train, cg_val, cg_test = fe.temporal_split(cg, train_end, val_end)

print(f"res — train: {res_train.count():,}  val: {res_val.count():,}  test: {res_test.count():,}")
print(f"rtq — train: {rtq_train.count():,}  val: {rtq_val.count():,}  test: {rtq_test.count():,}")
print(f"cg  — train: {cg_train.count():,}  val: {cg_val.count():,}  test: {cg_test.count():,}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Part 2b — Missing Value Imputation (mode, fit on TRAIN only)
# MAGIC Runs **after** the split and **before** any aggregation/scaling, on the
# MAGIC raw per-instance columns. The mode is computed from `*_train` only and
# MAGIC the same fixed values are applied to val/test — no statistic is ever
# MAGIC computed on val/test data.

# COMMAND ----------

print("Fitting resource mode-imputer on TRAIN only...")
res_impute_stats = fe.fit_mode_imputer(res_train, RES_IMPUTE_COLS)

res_train = fe.apply_mode_imputer(res_train, res_impute_stats)
res_val = fe.apply_mode_imputer(res_val, res_impute_stats)
res_test = fe.apply_mode_imputer(res_test, res_impute_stats)

# COMMAND ----------

from pyspark.sql import functions as F
display(res_train.select([F.count(F.when(F.col(c).isNull(), c)).alias(c) for c in res_train.columns]))

# COMMAND ----------

res.head()

# COMMAND ----------

# MAGIC %md ## Part 3 — Global Node Index

# COMMAND ----------

node_index = fe.build_node_index(
    spark,
    res_splits=(res_train, res_val, res_test),
    cg_splits=(cg_train, cg_val, cg_test),
    output_root=fe_output_root,
)
print(f"num_nodes = {node_index.count():,}")

# COMMAND ----------

# MAGIC %md ## Part 4 — Resource Feature Engineering

# COMMAND ----------

res_ms_train = fe.aggregate_res_to_msname(res_train)
res_ms_val = fe.aggregate_res_to_msname(res_val)
res_ms_test = fe.aggregate_res_to_msname(res_test)

print("Fitting resource scaler on TRAIN only...")
res_scale_stats = fe.fit_robust_scaler(res_ms_train, RES_AGG_COLS)

res_ms_train = fe.apply_robust_scaler(res_ms_train, res_scale_stats)
res_ms_val = fe.apply_robust_scaler(res_ms_val, res_scale_stats)
res_ms_test = fe.apply_robust_scaler(res_ms_test, res_scale_stats)

RES_SCALED_COLS = [f"{c}_rs" for c in RES_AGG_COLS]
print("Resource scaled columns:", RES_SCALED_COLS)

# COMMAND ----------

res_ms_train = fe.add_temporal_features(res_ms_train)
res_ms_val = fe.add_temporal_features(res_ms_val)
res_ms_test = fe.add_temporal_features(res_ms_test)

res_ms_train = fe.add_cyclical_time_features(res_ms_train)
res_ms_val = fe.add_cyclical_time_features(res_ms_val)
res_ms_test = fe.add_cyclical_time_features(res_ms_test)

# COMMAND ----------

# MAGIC %md ## Part 5 — RTQ Feature Engineering

# COMMAND ----------

# MAGIC %md
# MAGIC #### Missing value imputation (mode, fit on TRAIN only) — before aggregation

# COMMAND ----------

print("Fitting RTQ mode-imputer on TRAIN only...")
rtq_impute_stats = fe.fit_mode_imputer(rtq_train, all_rtq_cols)

rtq_train = fe.apply_mode_imputer(rtq_train, rtq_impute_stats)
rtq_val = fe.apply_mode_imputer(rtq_val, rtq_impute_stats)
rtq_test = fe.apply_mode_imputer(rtq_test, rtq_impute_stats)

# COMMAND ----------

rtq_ms_train = fe.aggregate_rtq_to_msname(rtq_train, mcr_cols, rt_cols)
rtq_ms_val = fe.aggregate_rtq_to_msname(rtq_val, mcr_cols, rt_cols)
rtq_ms_test = fe.aggregate_rtq_to_msname(rtq_test, mcr_cols, rt_cols)

rtq_ms_train = fe.fix_and_log_rtq(rtq_ms_train, rt_cols, all_rtq_cols)
rtq_ms_val = fe.fix_and_log_rtq(rtq_ms_val, rt_cols, all_rtq_cols)
rtq_ms_test = fe.fix_and_log_rtq(rtq_ms_test, rt_cols, all_rtq_cols)

RTQ_LOG_COLS = [f"{c}_log" for c in all_rtq_cols]

print("Fitting RTQ scaler on TRAIN only...")
rtq_scale_stats = fe.fit_robust_scaler(rtq_ms_train, RTQ_LOG_COLS)

rtq_ms_train = fe.apply_robust_scaler(rtq_ms_train, rtq_scale_stats)
rtq_ms_val = fe.apply_robust_scaler(rtq_ms_val, rtq_scale_stats)
rtq_ms_test = fe.apply_robust_scaler(rtq_ms_test, rtq_scale_stats)

RTQ_SCALED_COLS = [f"{c}_rs" for c in RTQ_LOG_COLS]
print("RTQ scaled columns:", RTQ_SCALED_COLS)

# COMMAND ----------

# MAGIC %md ## Part 6 — Build Final Node Feature Table

# COMMAND ----------

ALL_NODE_FEATURE_COLS = RES_SCALED_COLS + fe.ROLLING_COLS + RTQ_SCALED_COLS + ["t_sin", "t_cos"]
print(f"Total node feature dims: {len(ALL_NODE_FEATURE_COLS)}")
for i, c in enumerate(ALL_NODE_FEATURE_COLS, 1):
    print(f"  {i:2d}. {c}")

# COMMAND ----------

node_feat_train = fe.build_node_features(res_ms_train, rtq_ms_train, node_index, RTQ_SCALED_COLS, ALL_NODE_FEATURE_COLS)
node_feat_val = fe.build_node_features(res_ms_val, rtq_ms_val, node_index, RTQ_SCALED_COLS, ALL_NODE_FEATURE_COLS)
node_feat_test = fe.build_node_features(res_ms_test, rtq_ms_test, node_index, RTQ_SCALED_COLS, ALL_NODE_FEATURE_COLS)

# COMMAND ----------

# MAGIC %md ## Part 7 — Edge Feature Engineering

# COMMAND ----------

cg_clean_train = fe.clean_and_aggregate_cg(cg_train)
cg_clean_val = fe.clean_and_aggregate_cg(cg_val)
cg_clean_test = fe.clean_and_aggregate_cg(cg_test)

print("Fitting rpctype encoder on TRAIN only...")
rpctype_model = fe.fit_rpctype_encoder(cg_clean_train)
cg_clean_train = rpctype_model.transform(cg_clean_train)
cg_clean_val = rpctype_model.transform(cg_clean_val)
cg_clean_test = rpctype_model.transform(cg_clean_test)

print("Fitting edge scaler on TRAIN only...")
edge_scale_stats = fe.fit_robust_scaler(cg_clean_train, EDGE_LOG_COLS)

cg_clean_train = fe.apply_robust_scaler(cg_clean_train, edge_scale_stats)
cg_clean_val = fe.apply_robust_scaler(cg_clean_val, edge_scale_stats)
cg_clean_test = fe.apply_robust_scaler(cg_clean_test, edge_scale_stats)

EDGE_SCALED_COLS = [f"{c}_rs" for c in EDGE_LOG_COLS]
EDGE_FEATURE_COLS = EDGE_SCALED_COLS + ["rpctype_idx"]
print("Edge feature columns:", EDGE_FEATURE_COLS)

# COMMAND ----------

edge_feat_train = fe.build_edge_features(cg_clean_train, node_index, EDGE_FEATURE_COLS)
edge_feat_val = fe.build_edge_features(cg_clean_val, node_index, EDGE_FEATURE_COLS)
edge_feat_test = fe.build_edge_features(cg_clean_test, node_index, EDGE_FEATURE_COLS)

# COMMAND ----------

# MAGIC %md ## Part 8 — Write Snapshots + Manifests + Dataset Stats

# COMMAND ----------

fe.write_snapshots(node_feat_train, edge_feat_train, "train", fe_output_root)
fe.write_snapshots(node_feat_val, edge_feat_val, "val", fe_output_root)
fe.write_snapshots(node_feat_test, edge_feat_test, "test", fe_output_root)

# COMMAND ----------

manifests = {
    "train": fe.write_manifest(spark, node_feat_train, "train", fe_output_root),
    "val": fe.write_manifest(spark, node_feat_val, "val", fe_output_root),
    "test": fe.write_manifest(spark, node_feat_test, "test", fe_output_root),
}

# COMMAND ----------

import json as _json
stats = fe.write_dataset_stats(spark, node_index, ALL_NODE_FEATURE_COLS, EDGE_FEATURE_COLS, manifests, fe_output_root)
print(_json.dumps(stats, indent=2))

# COMMAND ----------

# MAGIC %md ## Part 9 — Sanity Check

# COMMAND ----------

for split, manifest in manifests.items():
    t0 = manifest["t_indices"][0]
    nodes = spark.read.option("basePath", f"{fe_output_root}/snapshots/{split}/nodes") \
        .parquet(f"{fe_output_root}/snapshots/{split}/nodes/t_idx={t0}")
    edges = spark.read.option("basePath", f"{fe_output_root}/snapshots/{split}/edges") \
        .parquet(f"{fe_output_root}/snapshots/{split}/edges/t_idx={t0}")

    print(f"\n=== {split.upper()} ===")
    print(f"  Snapshots  : {manifest['count']}  (t={manifest['t_indices'][0]} -> t={manifest['t_indices'][-1]})")
    print(f"  t={t0} nodes : {nodes.count():,}")
    print(f"  t={t0} edges : {edges.count():,}")

print("\nFeature engineering stage complete.")